/** Automatically generated file. DO NOT MODIFY */
package com.iapppay.android.res;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}