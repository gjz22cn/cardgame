/** Automatically generated file. DO NOT MODIFY */
package com.mappn.sdk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}